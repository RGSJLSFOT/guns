/**
 * 统计报表管理初始化
 */
var Statistics = {
    id: "StatisticsTable",	//表格id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};

/**
 * 初始化表格的列
 */
Statistics.initColumn = function () {
    return [
        {field: 'selectItem', radio: true},
            {title: '', field: 'type', visible: true, align: 'center', valign: 'middle'},
            {title: '', field: 'vendorId', visible: true, align: 'center', valign: 'middle'},
            {title: '', field: 'projectId', visible: true, align: 'center', valign: 'middle'},
            {title: '', field: 'vendorName', visible: true, align: 'center', valign: 'middle'},
            {title: '', field: 'projectName', visible: true, align: 'center', valign: 'middle'},
            {title: '', field: 'userId', visible: true, align: 'center', valign: 'middle'},
            {title: '', field: 'date', visible: true, align: 'center', valign: 'middle'},
            {title: '', field: 'timelong', visible: true, align: 'center', valign: 'middle'}
    ];
};

/**
 * 检查是否选中
 */
Statistics.check = function () {
    var selected = $('#' + this.id).bootstrapTable('getSelections');
    if(selected.length == 0){
        Feng.info("请先选中表格中的某一记录！");
        return false;
    }else{
        Statistics.seItem = selected[0];
        return true;
    }
};

/**
 * 点击添加统计报表
 */
Statistics.openAddStatistics = function () {
    var index = layer.open({
        type: 2,
        title: '添加统计报表',
        area: ['800px', '420px'], //宽高
        fix: false, //不固定
        maxmin: true,
        content: Feng.ctxPath + '/statistics/statistics_add'
    });
    this.layerIndex = index;
};

/**
 * 打开查看统计报表详情
 */
Statistics.openStatisticsDetail = function () {
    if (this.check()) {
        var index = layer.open({
            type: 2,
            title: '统计报表详情',
            area: ['800px', '420px'], //宽高
            fix: false, //不固定
            maxmin: true,
            content: Feng.ctxPath + '/statistics/statistics_update/' + Statistics.seItem.id
        });
        this.layerIndex = index;
    }
};

/**
 * 删除统计报表
 */
Statistics.delete = function () {
    if (this.check()) {
        var ajax = new $ax(Feng.ctxPath + "/statistics/delete", function (data) {
            Feng.success("删除成功!");
            Statistics.table.refresh();
        }, function (data) {
            Feng.error("删除失败!" + data.responseJSON.message + "!");
        });
        ajax.set("statisticsId",this.seItem.id);
        ajax.start();
    }
};

/**
 * 查询统计报表列表
 */
Statistics.search = function () {
    var queryData = {};
    queryData['condition'] = $("#condition").val();
    Statistics.table.refresh({query: queryData});
};

$(function () {
    var defaultColunms = Statistics.initColumn();
    var table = new BSTable(Statistics.id, "/statistics/list", defaultColunms);
    table.setPaginationType("client");
    Statistics.table = table.init();
});
