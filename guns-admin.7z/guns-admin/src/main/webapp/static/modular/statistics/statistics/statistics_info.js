/**
 * 初始化统计报表详情对话框
 */
var StatisticsInfoDlg = {
    statisticsInfoData : {}
};

/**
 * 清除数据
 */
StatisticsInfoDlg.clearData = function() {
    this.statisticsInfoData = {};
}

/**
 * 设置对话框中的数据
 *
 * @param key 数据的名称
 * @param val 数据的具体值
 */
StatisticsInfoDlg.set = function(key, val) {
    this.statisticsInfoData[key] = (typeof val == "undefined") ? $("#" + key).val() : val;
    return this;
}

/**
 * 设置对话框中的数据
 *
 * @param key 数据的名称
 * @param val 数据的具体值
 */
StatisticsInfoDlg.get = function(key) {
    return $("#" + key).val();
}

/**
 * 关闭此对话框
 */
StatisticsInfoDlg.close = function() {
    parent.layer.close(window.parent.Statistics.layerIndex);
}

/**
 * 收集数据
 */
StatisticsInfoDlg.collectData = function() {
    this
    .set('type')
    .set('vendorId')
    .set('projectId')
    .set('vendorName')
    .set('projectName')
    .set('userId')
    .set('date')
    .set('timelong');
}

/**
 * 提交添加
 */
StatisticsInfoDlg.addSubmit = function() {

    this.clearData();
    this.collectData();

    //提交信息
    var ajax = new $ax(Feng.ctxPath + "/statistics/add", function(data){
        Feng.success("添加成功!");
        window.parent.Statistics.table.refresh();
        StatisticsInfoDlg.close();
    },function(data){
        Feng.error("添加失败!" + data.responseJSON.message + "!");
    });
    ajax.set(this.statisticsInfoData);
    ajax.start();
}

/**
 * 提交修改
 */
StatisticsInfoDlg.editSubmit = function() {

    this.clearData();
    this.collectData();

    //提交信息
    var ajax = new $ax(Feng.ctxPath + "/statistics/update", function(data){
        Feng.success("修改成功!");
        window.parent.Statistics.table.refresh();
        StatisticsInfoDlg.close();
    },function(data){
        Feng.error("修改失败!" + data.responseJSON.message + "!");
    });
    ajax.set(this.statisticsInfoData);
    ajax.start();
}

$(function() {

});
