/**
 * 审核记录管理初始化
 */
var SubmitRecord = {
    id: "SubmitRecordTable",	//表格id
    seItem: null,		//选中的条目
    table: null,
    layerIndex: -1
};

/**
 * 初始化表格的列
 */
SubmitRecord.initColumn = function () {
    return [
        {field: 'selectItem', radio: true},
            {title: 'Id', field: 'Id', visible: false, align: 'center', valign: 'middle'},
            {title: '类型代码', field: 'type', visible: false, align: 'center', valign: 'middle'},
            {title: '类型名称', field: 'typeName', visible: true, align: 'center', valign: 'middle'},
            {title: '供应商', field: 'vendorName', visible: true, align: 'center', valign: 'middle'},
            {title: '项目', field: 'projectName', visible: true, align: 'center', valign: 'middle'},
            {title: '工号', field: 'userId', visible: true, align: 'center', valign: 'middle'},
            {title: '中文名', field: 'vendorUserChName', visible: true, align: 'center', valign: 'middle'},
            {title: '英文名', field: 'vendorUserEnName', visible: true, align: 'center', valign: 'middle'},
            {title: '日期', field: 'date', visible: false, align: 'center', valign: 'middle'},
            {title: '日期', field: 'dateStr', visible: true, align: 'center', valign: 'middle'},
            {title: '时长', field: 'hours', visible: true, align: 'center', valign: 'middle'}
            /*   {title: '工时', field: 'workHours', visible: false, align: 'center', valign: 'middle'},
            {title: '加班', field: 'overHours', visible: false, align: 'center', valign: 'middle'},
            {title: '请假', field: 'leaveHours', visible: false, align: 'center', valign: 'middle'}
            
         {title: '业务Id', field: 'ywId', visible: true, align: 'center', valign: 'middle'},
            {title: '提交人工号', field: 'submitUserId', visible: true, align: 'center', valign: 'middle'},
            {title: '提交时间', field: 'submitTime', visible: true, align: 'center', valign: 'middle'},
            {title: '审核人工号', field: 'auditUserId', visible: true, align: 'center', valign: 'middle'},
            {title: '审核时间', field: 'auditTime', visible: true, align: 'center', valign: 'middle'},
            {title: '审核结果', field: 'auditResult', visible: true, align: 'center', valign: 'middle'}*/
    ];
};

/**
 * 检查是否选中
 */
SubmitRecord.check = function () {
    var selected = $('#' + this.id).bootstrapTable('getSelections');
    if(selected.length == 0){
        Feng.info("请先选中表格中的某一记录！");
        return false;
    }else{
        SubmitRecord.seItem = selected[0];
        return true;
    }
};

/**
 * 点击添加审核记录
 */
SubmitRecord.openAddSubmitRecord = function () {
    var index = layer.open({
        type: 2,
        title: '添加审核记录',
        area: ['800px', '420px'], //宽高
        fix: false, //不固定
        maxmin: true,
        content: Feng.ctxPath + '/submitRecord/submitRecord_add'
    });
    this.layerIndex = index;
};

/**
 * 打开查看审核记录详情
 */
SubmitRecord.openSubmitRecordDetail = function () {
    if (this.check()) {
        var index = layer.open({
            type: 2,
            title: '审核记录详情',
            area: ['800px', '420px'], //宽高
            fix: false, //不固定
            maxmin: true,
            content: Feng.ctxPath + '/submitRecord/submitRecord_update/' + SubmitRecord.seItem.id
        });
        this.layerIndex = index;
    }
};

/**
 * 删除审核记录
 */
SubmitRecord.delete = function () {
    if (this.check()) {
        var ajax = new $ax(Feng.ctxPath + "/submitRecord/delete", function (data) {
            Feng.success("删除成功!");
            SubmitRecord.table.refresh();
        }, function (data) {
            Feng.error("删除失败!" + data.responseJSON.message + "!");
        });
        ajax.set("submitRecordId",this.seItem.id);
        ajax.start();
    }
};

/**
 * 查询审核记录列表
 */
SubmitRecord.search = function () {
    var queryData = {};
    queryData['type'] = $("#type").val();
    queryData['startDate'] = $("#startDate").val();
    queryData['endDate'] = $("#endDate").val();
    queryData['projectId'] = $("#projectId").val();
    queryData['vendorId'] = $("#vendorId").val();
    queryData['userId'] = $("#userId").val();
    
    SubmitRecord.table.refresh({query: queryData});
};

/**
 * 导出excel
 */
SubmitRecord.export = function () {
	var form = document.createElement("form");
	debugger
	form.action=Feng.ctxPath + "/submitRecord/export";
	form.method="post";
	form.type = $("#type").val();
	form.startDate = $("#startDate").val();
	form.endDate = $("#endDate").val();
	form.projectId = $("#projectId").val();
	form.vendorId = $("#vendorId").val();
	form.userId = $("#userId").val();
	
	document.body.appendChild(form);
	form.submit();
  /*  var ajax = new $ax(Feng.ctxPath + "/submitRecord/export", function (data) {
        Feng.success("导出成功!");
        //SubmitRecord.table.refresh();
    }, function (data) {
        Feng.error("导出失败!" + data.responseJSON.message + "!");
    });
    
    ajax.set("type",$("#type").val());
    ajax.set("startDate",$("#startDate").val());
    ajax.set("endDate",$("#endDate").val());
    ajax.set("projectId",$("#projectId").val());
    ajax.set("vendorId",$("#vendorId").val());
    ajax.set("userId",$("#userId").val());
    ajax.start();*/
};

/**
 * 选择project的事件
 */
SubmitRecord.selectProj = function (projId) {
	$("#projectId").val(projId);
};
 
/**
 * 选择vendor的事件
 */
SubmitRecord.selectVendor = function (vendorId) {
	$("#vendorId").val(vendorId);
};

$(function () {
    var defaultColunms = SubmitRecord.initColumn();
    var table = new BSTable(SubmitRecord.id, "/submitRecord/list", defaultColunms);
    table.setPaginationType("client");
    SubmitRecord.table = table.init();
});
