package com.stylefeng.guns.modular.leaveTime.service;

import com.stylefeng.guns.core.datascope.DataScope;
import com.stylefeng.guns.modular.system.model.LeaveTime;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guangsen
 * @since 2018-12-06
 */
public interface ILeaveTimeService extends IService<LeaveTime> {
	/**
     * 根据条件查询请假列表
     */
    List<Map<String, Object>> selectLeaveTimes(String userId, String leaveType, String beginTime, String endTime);
    
    List<Map<String, Object>> selectLeaveTimesToAudit(String userId,Integer leaveType, String leaveDate, String leaderId);

    List<Map<String, Object>> selectLeaveTimesAudited(String userId,Integer leaveType, String leaveDate, String leaderId);
	
	int updateSubmitStatusById(Integer submitStatus,Integer Id);

}
