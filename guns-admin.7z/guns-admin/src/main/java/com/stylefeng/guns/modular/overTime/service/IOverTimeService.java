package com.stylefeng.guns.modular.overTime.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.service.IService;
import com.stylefeng.guns.modular.system.model.OverTime;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guangsen
 * @since 2018-12-06
 */
public interface IOverTimeService extends IService<OverTime> {
	List<Map<String, Object>> selectOverTimesToAudit(String userId, String startTime, String leaderId);
	
	List<Map<String, Object>> selectOverTimesAudited(String userId, String startTime, String leaderId);
	
	int updateSubmitStatusById(Integer submitStatus, Integer Id);
}
