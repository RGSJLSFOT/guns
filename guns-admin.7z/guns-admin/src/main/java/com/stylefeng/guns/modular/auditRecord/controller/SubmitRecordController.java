package com.stylefeng.guns.modular.auditRecord.controller;

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.stylefeng.guns.core.base.controller.BaseController;
import com.stylefeng.guns.core.log.LogObjectHolder;
import com.stylefeng.guns.modular.auditRecord.service.ExcelUtil;
import com.stylefeng.guns.modular.auditRecord.service.ISubmitRecordService;
import com.stylefeng.guns.modular.statistics.service.IStatisticsService;
import com.stylefeng.guns.modular.system.model.Statistics;
import com.stylefeng.guns.modular.system.model.StatisticsParam;
import com.stylefeng.guns.modular.system.model.SubmitRecord;
import com.stylefeng.guns.modular.system.warpper.submitRecordWarpper;
import com.stylefeng.guns.modular.vendorUser.service.ProjService;

/**
 * 审核记录控制器
 *
 * @author fengshuonan
 * @Date 2018-12-12 10:20:36
 */
@Controller
@RequestMapping("/submitRecord")
public class SubmitRecordController extends BaseController {

    private String PREFIX = "/auditRecord/submitRecord/";

    @Autowired
    private ISubmitRecordService submitRecordService;
    
    @Autowired 
    private IStatisticsService iStatisticsService;
    
    @Autowired
    private ProjService projService;
    /**
     * 跳转到审核记录首页
     */
    @RequestMapping("")
    public String index(Model model) {
    	model.addAttribute("vendors", projService.getAllVendors());
    	model.addAttribute("projects", projService.getAllProjects());
        return PREFIX + "submitRecord.html";
    }

    /**
     * 跳转到添加审核记录
     */
    @RequestMapping("/submitRecord_add")
    public String submitRecordAdd() {
        return PREFIX + "submitRecord_add.html";
    }

    /**
     * 跳转到修改审核记录
     */
    @RequestMapping("/submitRecord_update/{submitRecordId}")
    public String submitRecordUpdate(@PathVariable Integer submitRecordId, Model model) {
        SubmitRecord submitRecord = submitRecordService.selectById(submitRecordId);
        model.addAttribute("item",submitRecord);
        LogObjectHolder.me().set(submitRecord);
        return PREFIX + "submitRecord_edit.html";
    }

    /**
     * 获取审核记录列表
     */
    @RequestMapping(value = "/list")
    @ResponseBody
    public Object list(Integer type,String startDate,String endDate,Integer projectId,Integer vendorId,String userId) {
    	return new submitRecordWarpper(iStatisticsService.statistics(type, startDate, endDate, projectId, vendorId, userId)).warp();
    }

    /**
     * 导出excel
     * @param request
     * @param response
     * @throws Exception
     */
    @RequestMapping(value = "/export")
    @ResponseBody
    public String export(StatisticsParam statisticsParam,HttpServletResponse response) throws Exception {
       List<Map<String,Object>> list = (List<Map<String,Object>>) new submitRecordWarpper(
    		   iStatisticsService.statistics(statisticsParam.getType(), statisticsParam.getStartdate().toString(), statisticsParam.getEnddate().toString(), statisticsParam.getProjectId(), statisticsParam.getVendorId(), statisticsParam.getUserId())
    		   
    		   ).warp();
       
       String[] title = {"类型","供应商","项目","中文名","英文名","工号","时长"};
       String fileName = "工时统计"+System.currentTimeMillis()+".xls";
       String[] sheetName ={"明细","汇总"};
       String[][] content = {{},{}};
       for (int i = 0; i < list.size(); i++) {
			content[i] = new String[title.length];
			Map<String,Object> obj = list.get(i);
            content[i][0] = obj.get("typeName").toString();
            content[i][1] = obj.get("vendorName").toString();
            content[i][2] = obj.get("projectName").toString();
            content[i][3] = obj.get("vendorUserChName").toString();
            content[i][4] = obj.get("vendorUserEnName").toString();
            content[i][5] = obj.get("userId").toString();
            content[i][6] = obj.get("hours").toString();
       }
       HSSFWorkbook wb = ExcelUtil.getHSSFWorkbook(sheetName, title, content, null);
       
       try {
    	   	this.setResponseHeader(response, fileName);
			OutputStream os = response.getOutputStream();
			wb.write(os);
			os.flush();
			os.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
       return "OK";
}
    
  //发送响应流方法
    public void setResponseHeader(HttpServletResponse response, String fileName) {
        try {
            try {
                fileName = new String(fileName.getBytes(),"ISO8859-1");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            response.setContentType("application/octet-stream;charset=ISO8859-1");
            response.setHeader("Content-Disposition", "attachment;filename="+ fileName);
            response.addHeader("Pargam", "no-cache");
            response.addHeader("Cache-Control", "no-cache");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    /**
     * 新增审核记录
     */
    @RequestMapping(value = "/add")
    @ResponseBody
    public Object add(SubmitRecord submitRecord) {
        submitRecordService.insert(submitRecord);
        return SUCCESS_TIP;
    }

    /**
     * 删除审核记录
     */
    @RequestMapping(value = "/delete")
    @ResponseBody
    public Object delete(@RequestParam Integer submitRecordId) {
        submitRecordService.deleteById(submitRecordId);
        return SUCCESS_TIP;
    }

    /**
     * 修改审核记录
     */
    @RequestMapping(value = "/update")
    @ResponseBody
    public Object update(SubmitRecord submitRecord) {
        submitRecordService.updateById(submitRecord);
        return SUCCESS_TIP;
    }

    /**
     * 审核记录详情
     */
    @RequestMapping(value = "/detail/{submitRecordId}")
    @ResponseBody
    public Object detail(@PathVariable("submitRecordId") Integer submitRecordId) {
        return submitRecordService.selectById(submitRecordId);
    }
}
