package com.stylefeng.guns.modular.system.model;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableName;

import java.io.Serializable;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author stylefeng
 * @since 2018-12-20
 */
@TableName("v_statistics")
public class Statistics extends Model<Statistics> {

    private static final long serialVersionUID = 1L;

    private Long type;
    private String typeName;
    private Integer vendorId;
    private Integer projectId;
    private String vendorName;
    private String projectName;
    private String userId;
    private Date date;
	private BigDecimal workHours;
    private BigDecimal overHours;
    private BigDecimal leaveHours;


    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public Integer getVendorId() {
        return vendorId;
    }

    public void setVendorId(Integer vendorId) {
        this.vendorId = vendorId;
    }

    public Integer getProjectId() {
        return projectId;
    }

    public void setProjectId(Integer projectId) {
        this.projectId = projectId;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDate() {
    	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd");
        return sdf.format(date);
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public BigDecimal getWorkHours() {
		return workHours;
	}

	public void setWorkHours(BigDecimal workHours) {
		this.workHours = workHours;
	}

	public BigDecimal getOverHours() {
		return overHours;
	}

	public void setOverHours(BigDecimal overHours) {
		this.overHours = overHours;
	}

	public BigDecimal getLeaveHours() {
		return leaveHours;
	}

	public void setLeaveHours(BigDecimal leaveHours) {
		this.leaveHours = leaveHours;
	}

    @Override
    protected Serializable pkVal() {
        return null;
    }

    @Override
    public String toString() {
        return "Statistics{" +
        "type=" + type +
        ", typeName=" + typeName +
        ", vendorId=" + vendorId +
        ", projectId=" + projectId +
        ", vendorName=" + vendorName +
        ", projectName=" + projectName +
        ", userId=" + userId +
        ", date=" + date +
        ", workHours=" + workHours +
        ", overHours=" + overHours +
        ", leaveHours=" + leaveHours +
        "}";
    }

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
}
