package com.stylefeng.guns.core.common.constant.factory;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.stylefeng.guns.core.common.constant.cache.Cache;
import com.stylefeng.guns.core.common.constant.cache.CacheKey;
import com.stylefeng.guns.core.common.constant.state.LeaveType;
import com.stylefeng.guns.core.common.constant.state.ManagerStatus;
import com.stylefeng.guns.core.common.constant.state.MenuStatus;
import com.stylefeng.guns.core.log.LogObjectHolder;
import com.stylefeng.guns.core.support.StrKit;
import com.stylefeng.guns.core.util.Convert;
import com.stylefeng.guns.core.util.SpringContextHolder;
import com.stylefeng.guns.core.util.ToolUtil;
import com.stylefeng.guns.modular.system.dao.*;
import com.stylefeng.guns.modular.system.model.*;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 常量的生产工厂
 *
 * @author fengshuonan
 * @date 2017年2月13日 下午10:55:21
 */
@Component
public class ConstantFactory {

    public static ConstantFactory me() {
        return SpringContextHolder.getBean(ConstantFactory.class);
    }

    /**
     * 根据用户id获取用户名称
     *
     * @author stylefeng
     * @Date 2017/5/9 23:41
     */
    public String getUserNameById(Integer userId) {
        User user = SpringContextHolder.getBean(UserMapper.class).selectById(userId);
        if (user != null) {
            return user.getName();
        } else {
            return "--";
        }
    }
    
    /**
     * 根据字典中所有请假类型
     *
     */
    public List<Dict> getDictsByName(String name) {
        Dict temp = new Dict();
        temp.setName(name);
        Dict dict = SpringContextHolder.getBean(DictMapper.class).selectOne(temp);
        if (dict == null) {
            return null;
        } else {
            Wrapper<Dict> wrapper = new EntityWrapper<>();
            wrapper = wrapper.eq("pid", dict.getId());
            return SpringContextHolder.getBean(DictMapper.class).selectList(wrapper);
        }
    }
    
    /**
     * 根据供应商用户工号获取供应商用户名称
     *
     * @author stylefeng
     * @Date 2017/5/9 23:41
     */
    
    public VendorUser getVendorUserByAccount(String userId) {
    	return SpringContextHolder.getBean(VendorUserMapper.class).selectByUserNO(userId);
    }
    
    /**
     * 根据用户id获取用户名称
     *
     * @author stylefeng
     * @Date 2017/5/9 23:41
     */
    public String getUserNameByAccount(String account) {
    	User user = SpringContextHolder.getBean(UserMapper.class).getByAccount(account);
    	if (user != null) {
    		return user.getName();
    	} else {
    		return "--";
    	}
    }
    
    /**
     * 根据项目id获取项目名称
     *
     * @author guangsen
     * @Date 2018/12/7 12:41
     */
    public String getProjectNameById(Integer projcetId) {
        Project project = SpringContextHolder.getBean(ProjectMapper.class).selectById(projcetId);
        if (project != null) {
            return project.getProjectName();
        } else {
            return "--";
        }
    }
    
    /**
     * 根据userId获取供应商Id
     *
     * @author guangsen
     * @Date 2018/12/7 12:41
     */
    public String getVendorNameById(Integer vendorId) {
        Vendors vendors = SpringContextHolder.getBean(VendorsMapper.class).selectById(vendorId);
        if (vendors != null) {
            return vendors.getVendorNameCh();
        } else {
            return "--";
        }
    }
    
    
    /**
     * 根据userId获取供应商名称
     *
     * @author guangsen
     * @Date 2018/12/7 12:41
     */
    public String getVendorNameByUserId(String userId) {
    	VendorUser vendoruser = SpringContextHolder.getBean(VendorUserMapper.class).selectByUserNO(userId);
    	Vendors vendors = SpringContextHolder.getBean(VendorsMapper.class).selectById(vendoruser.getVendorId());
    	if (vendors != null) {
            return vendors.getVendorNameCh();
        } else {
            return "--";
        }
    }
    
    /**
     * 根据userId获取项目名称
     *
     * @author guangsen
     * @Date 2018/12/7 12:41
     */
    public String getProjectNameByUserId(String userId) {
    	VendorUser vendoruser = SpringContextHolder.getBean(VendorUserMapper.class).selectByUserNO(userId);
    	Project project = SpringContextHolder.getBean(ProjectMapper.class).selectById(vendoruser.getProjectId());
    	if (project != null) {
            return project.getProjectName();
        } else {
            return "--";
        }
    }
    
    /**
     * 根据用户id获取用户账号
     *
     * @author stylefeng
     * @date 2017年5月16日21:55:371
     */
    public String getUserAccountById(Integer userId) {
        User user = SpringContextHolder.getBean(UserMapper.class).selectById(userId);
        if (user != null) {
            return user.getAccount();
        } else {
            return "--";
        }
    }

    /**
     * 通过角色ids获取角色名称
     */
    @Cacheable(value = Cache.CONSTANT, key = "'" + CacheKey.ROLES_NAME + "'+#roleIds")
    public String getRoleName(String roleIds) {
        Integer[] roles = Convert.toIntArray(roleIds);
        StringBuilder sb = new StringBuilder();
        for (int role : roles) {
            Role roleObj = SpringContextHolder.getBean(RoleMapper.class).selectById(role);
            if (ToolUtil.isNotEmpty(roleObj) && ToolUtil.isNotEmpty(roleObj.getName())) {
                sb.append(roleObj.getName()).append(",");
            }
        }
        return StrKit.removeSuffix(sb.toString(), ",");
    }

    /**
     * 通过角色id获取角色名称
     */
    @Cacheable(value = Cache.CONSTANT, key = "'" + CacheKey.SINGLE_ROLE_NAME + "'+#roleId")
    public String getSingleRoleName(Integer roleId) {
        if (0 == roleId) {
            return "--";
        }
        Role roleObj = SpringContextHolder.getBean(RoleMapper.class).selectById(roleId);
        if (ToolUtil.isNotEmpty(roleObj) && ToolUtil.isNotEmpty(roleObj.getName())) {
            return roleObj.getName();
        }
        return "";
    }

    /**
     * 通过角色id获取角色英文名称
     */
    @Cacheable(value = Cache.CONSTANT, key = "'" + CacheKey.SINGLE_ROLE_TIP + "'+#roleId")
    public String getSingleRoleTip(Integer roleId) {
        if (0 == roleId) {
            return "--";
        }
        Role roleObj = SpringContextHolder.getBean(RoleMapper.class).selectById(roleId);
        if (ToolUtil.isNotEmpty(roleObj) && ToolUtil.isNotEmpty(roleObj.getName())) {
            return roleObj.getTips();
        }
        return "";
    }

    /**
     * 获取部门名称
     */
    @Cacheable(value = Cache.CONSTANT, key = "'" + CacheKey.DEPT_NAME + "'+#deptId")
    public String getDeptName(Integer deptId) {
        Dept dept = SpringContextHolder.getBean(DeptMapper.class).selectById(deptId);
        if (ToolUtil.isNotEmpty(dept) && ToolUtil.isNotEmpty(dept.getFullname())) {
            return dept.getFullname();
        }
        return "";
    }

    /**
     * 获取菜单的名称们(多个)
     */
    public String getMenuNames(String menuIds) {
        Integer[] menus = Convert.toIntArray(menuIds);
        StringBuilder sb = new StringBuilder();
        for (int menu : menus) {
            Menu menuObj = SpringContextHolder.getBean(MenuMapper.class).selectById(menu);
            if (ToolUtil.isNotEmpty(menuObj) && ToolUtil.isNotEmpty(menuObj.getName())) {
                sb.append(menuObj.getName()).append(",");
            }
        }
        return StrKit.removeSuffix(sb.toString(), ",");
    }

    /**
     * 获取菜单名称
     */
    public String getMenuName(Long menuId) {
        if (ToolUtil.isEmpty(menuId)) {
            return "";
        } else {
            Menu menu = SpringContextHolder.getBean(MenuMapper.class).selectById(menuId);
            if (menu == null) {
                return "";
            } else {
                return menu.getName();
            }
        }
    }

    /**
     * 获取菜单名称通过编号
     */
    public String getMenuNameByCode(String code) {
        if (ToolUtil.isEmpty(code)) {
            return "";
        } else {
            Menu param = new Menu();
            param.setCode(code);
            Menu menu = SpringContextHolder.getBean(MenuMapper.class).selectOne(param);
            if (menu == null) {
                return "";
            } else {
                return menu.getName();
            }
        }
    }

    /**
     * 获取字典名称
     */
    public String getDictName(Integer dictId) {
        if (ToolUtil.isEmpty(dictId)) {
            return "";
        } else {
            Dict dict = SpringContextHolder.getBean(DictMapper.class).selectById(dictId);
            if (dict == null) {
                return "";
            } else {
                return dict.getName();
            }
        }
    }

    /**
     * 获取通知标题
     */
    public String getNoticeTitle(Integer dictId) {
        if (ToolUtil.isEmpty(dictId)) {
            return "";
        } else {
            Notice notice = SpringContextHolder.getBean(NoticeMapper.class).selectById(dictId);
            if (notice == null) {
                return "";
            } else {
                return notice.getTitle();
            }
        }
    }

    /**
     * 根据字典名称和字典中的值获取对应的名称
     */
    public String getDictsByName(String name, Integer val) {
        Dict temp = new Dict();
        temp.setName(name);
        Dict dict = SpringContextHolder.getBean(DictMapper.class).selectOne(temp);
        if (dict == null) {
            return "";
        } else {
            Wrapper<Dict> wrapper = new EntityWrapper<>();
            wrapper = wrapper.eq("pid", dict.getId());
            List<Dict> dicts = SpringContextHolder.getBean(DictMapper.class).selectList(wrapper);
            for (Dict item : dicts) {
                if (item.getNum() != null && item.getNum().equals(val)) {
                    return item.getName();
                }
            }
            return "";
        }
    }

    /**
     * 获取性别名称
     */
    public String getSexName(Integer sex) {
        return getDictsByName("性别", sex);
    }
    
    /**
     * 获取单据提交状态名称
     */
    public String getSubmitStatusName(Integer status) {
    	return getDictsByName("单据状态", status);
    }
    
    /**
     * 获取供应商人员状态名称
     */
    public String getVendorUserStatusName(Integer status) {
        return getDictsByName("供应商人员状态", status);
    }
    
    /**
     * 获取供应商人员岗位名称
     */
    public String getVendorUserPositionName(Integer PositionId) {
        return getDictsByName("岗位", PositionId);
    }
    /**
     * 获取供应商人员职级名称
     */
    public String getProfessionalLevelName(String status) {
    	return getDictsByName("职级", Integer.valueOf(status));
    }


    /**
     * 获取用户登录状态
     */
    public String getStatusName(Integer status) {
        return ManagerStatus.valueOf(status);
    }
    
    /**
     * 获取请假类型
     */
    public String getLeaveTypeName(Integer status) {
        return LeaveType.valueOf(status);
    }

    /**
     * 获取菜单状态
     */
    public String getMenuStatusName(Integer status) {
        return MenuStatus.valueOf(status);
    }

    /**
     * 查询字典
     */
    public List<Dict> findInDict(Integer id) {
        if (ToolUtil.isEmpty(id)) {
            return null;
        } else {
            EntityWrapper<Dict> wrapper = new EntityWrapper<>();
            List<Dict> dicts = SpringContextHolder.getBean(DictMapper.class).selectList(wrapper.eq("pid", id));
            if (dicts == null || dicts.size() == 0) {
                return null;
            } else {
                return dicts;
            }
        }
    }

    /**
     * 获取被缓存的对象(用户删除业务)
     */
    public String getCacheObject(String para) {
        return LogObjectHolder.me().get().toString();
    }

    /**
     * 获取子部门id
     */
    public List<Integer> getSubDeptId(Integer deptid) {
        Wrapper<Dept> wrapper = new EntityWrapper<>();
        wrapper = wrapper.like("pids", "%[" + deptid + "]%");
        List<Dept> depts = SpringContextHolder.getBean(DeptMapper.class).selectList(wrapper);

        ArrayList<Integer> deptids = new ArrayList<>();

        if (depts != null && depts.size() > 0) {
            for (Dept dept : depts) {
                deptids.add(dept.getId());
            }
        }

        return deptids;
    }

    /**
     * 获取所有父部门id
     */
    public List<Integer> getParentDeptIds(Integer deptid) {
        Dept dept = SpringContextHolder.getBean(DeptMapper.class).selectById(deptid);
        String pids = dept.getPids();
        String[] split = pids.split(",");
        ArrayList<Integer> parentDeptIds = new ArrayList<>();
        for (String s : split) {
            parentDeptIds.add(Integer.valueOf(StrKit.removeSuffix(StrKit.removePrefix(s, "["), "]")));
        }
        return parentDeptIds;
    }


}
