package com.stylefeng.guns.modular.project.service;

import com.stylefeng.guns.modular.system.model.Project;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guangsen
 * @since 2018-12-06
 */
public interface IProjectService extends IService<Project> {

}
