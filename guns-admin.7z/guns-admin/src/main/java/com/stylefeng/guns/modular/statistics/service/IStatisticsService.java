package com.stylefeng.guns.modular.statistics.service;

import java.util.List;
import java.util.Map;

import com.stylefeng.guns.modular.system.model.Statistics;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * VIEW 服务类
 * </p>
 *
 * @author stylefeng
 * @since 2018-12-20
 */
public interface IStatisticsService extends IService<Statistics> {
	List<Map<String,Object>> statistics (Integer type,String startDate,String endDate,Integer projectId,Integer vendorId,String userId);  
}
