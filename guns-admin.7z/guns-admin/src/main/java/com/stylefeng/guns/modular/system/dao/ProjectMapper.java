package com.stylefeng.guns.modular.system.dao;

import com.stylefeng.guns.modular.system.model.Project;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author guangsen
 * @since 2018-12-06
 */
public interface ProjectMapper extends BaseMapper<Project> {

}
