package com.stylefeng.guns.modular.system.model;

import java.util.Date;

/**
 * <p>
 * VIEW
 * </p>
 *
 * @author stylefeng
 * @since 2018-12-20
 */
public class StatisticsParam {

	private Integer type;
    private Integer vendorId;
    private Integer projectId;
    private String userId;
    private Date startdate;
    private Date enddate;
    
    
    public Integer getType() {
		return type;
	}



	public void setType(Integer type) {
		this.type = type;
	}



	public Integer getVendorId() {
		return vendorId;
	}



	public void setVendorId(Integer vendorId) {
		this.vendorId = vendorId;
	}



	public Integer getProjectId() {
		return projectId;
	}



	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}



	public String getUserId() {
		return userId;
	}



	public void setUserId(String userId) {
		this.userId = userId;
	}



	public Date getStartdate() {
		return startdate;
	}



	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}



	public Date getEnddate() {
		return enddate;
	}



	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}


    @Override
    public String toString() {
        return "Statistics{" +
        "type=" + type +
        ", vendorId=" + vendorId +
        ", projectId=" + projectId +
        ", userId=" + userId +
        ", startdate=" + startdate +
        ", enddate=" + enddate +
        "}";
    }

 
}
