package com.stylefeng.guns.modular.statistics.service.impl;

import java.util.List;
import java.util.Map;

import com.stylefeng.guns.modular.system.model.Statistics;
import com.stylefeng.guns.modular.system.dao.StatisticsMapper;
import com.stylefeng.guns.modular.statistics.service.IStatisticsService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import org.springframework.stereotype.Service;

/**
 * <p>
 * VIEW 服务实现类
 * </p>
 *
 * @author stylefeng
 * @since 2018-12-20
 */
@Service
public class StatisticsServiceImpl extends ServiceImpl<StatisticsMapper, Statistics> implements IStatisticsService {
	public List<Map<String,Object>> statistics (Integer type,String startDate,String endDate,Integer projectId,Integer vendorId,String userId){
		return this.baseMapper.statistics(type, startDate, endDate, projectId, vendorId, userId);
	}  
}
