package com.stylefeng.guns.modular.system.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.stylefeng.guns.modular.system.model.Statistics;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
 * VIEW Mapper 接口
 * </p>
 *
 * @author stylefeng
 * @since 2018-12-20
 */
public interface StatisticsMapper extends BaseMapper<Statistics> {
	 List<Map<String,Object>> statistics(@Param("type") Integer type,@Param("startDate")String startDate,@Param("endDate")String endDate,@Param("projectId")Integer projectId,@Param("vendorId")Integer vendorId,@Param("userId")String userId);
}
