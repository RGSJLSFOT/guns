package com.stylefeng.guns.modular.statistics.controller;

import com.stylefeng.guns.core.base.controller.BaseController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.beans.factory.annotation.Autowired;
import com.stylefeng.guns.core.log.LogObjectHolder;
import org.springframework.web.bind.annotation.RequestParam;
import com.stylefeng.guns.modular.system.model.Statistics;
import com.stylefeng.guns.modular.statistics.service.IStatisticsService;

/**
 * 统计报表控制器
 *
 * @author fengshuonan
 * @Date 2018-12-20 10:32:17
 */
@Controller
@RequestMapping("/statistics")
public class StatisticsController extends BaseController {

    private String PREFIX = "/statistics/statistics/";

    @Autowired
    private IStatisticsService statisticsService;

    /**
     * 跳转到统计报表首页
     */
    @RequestMapping("")
    public String index() {
        return PREFIX + "statistics.html";
    }

    /**
     * 跳转到添加统计报表
     */
    @RequestMapping("/statistics_add")
    public String statisticsAdd() {
        return PREFIX + "statistics_add.html";
    }

    /**
     * 跳转到修改统计报表
     */
    @RequestMapping("/statistics_update/{statisticsId}")
    public String statisticsUpdate(@PathVariable Integer statisticsId, Model model) {
        Statistics statistics = statisticsService.selectById(statisticsId);
        model.addAttribute("item",statistics);
        LogObjectHolder.me().set(statistics);
        return PREFIX + "statistics_edit.html";
    }

    /**
     * 获取统计报表列表
     */
    @RequestMapping(value = "/list")
    @ResponseBody
    public Object list(String condition) {
        return statisticsService.selectList(null);
    }

    /**
     * 新增统计报表
     */
    @RequestMapping(value = "/add")
    @ResponseBody
    public Object add(Statistics statistics) {
        statisticsService.insert(statistics);
        return SUCCESS_TIP;
    }

    /**
     * 删除统计报表
     */
    @RequestMapping(value = "/delete")
    @ResponseBody
    public Object delete(@RequestParam Integer statisticsId) {
        statisticsService.deleteById(statisticsId);
        return SUCCESS_TIP;
    }

    /**
     * 修改统计报表
     */
    @RequestMapping(value = "/update")
    @ResponseBody
    public Object update(Statistics statistics) {
        statisticsService.updateById(statistics);
        return SUCCESS_TIP;
    }

    /**
     * 统计报表详情
     */
    @RequestMapping(value = "/detail/{statisticsId}")
    @ResponseBody
    public Object detail(@PathVariable("statisticsId") Integer statisticsId) {
        return statisticsService.selectById(statisticsId);
    }
}
