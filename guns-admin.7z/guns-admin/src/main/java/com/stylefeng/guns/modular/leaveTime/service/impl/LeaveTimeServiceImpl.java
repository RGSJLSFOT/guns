package com.stylefeng.guns.modular.leaveTime.service.impl;

import com.stylefeng.guns.modular.system.model.LeaveTime;
import com.stylefeng.guns.modular.system.dao.LeaveTimeMapper;
import com.stylefeng.guns.core.datascope.DataScope;
import com.stylefeng.guns.modular.leaveTime.service.ILeaveTimeService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author guangsen
 * @since 2018-12-06
 */
@Service
public class LeaveTimeServiceImpl extends ServiceImpl<LeaveTimeMapper, LeaveTime> implements ILeaveTimeService {
	public List<Map<String, Object>> selectLeaveTimes(String userId,String leaveType,String beginTime,String endTime){
    	return this.baseMapper.selectLeaveTimes(userId,leaveType, beginTime,endTime);
    }
	
	public List<Map<String, Object>> selectLeaveTimesToAudit(String userId,Integer leaveType,String leaveDate,String leaderId) {
        return this.baseMapper.selectLeaveTimesToAudit(userId,leaveType,leaveDate,leaderId);
    }
	
	public List<Map<String, Object>> selectLeaveTimesAudited(String userId,Integer leaveType,String leaveDate,String leaderId) {
		return this.baseMapper.selectLeaveTimesAudited(userId,leaveType,leaveDate,leaderId);
	}
	
	public int updateSubmitStatusById(Integer submitStatus,Integer Id){
		 return this.baseMapper.updateSubmitStatusById(submitStatus,Id);
	};
}
