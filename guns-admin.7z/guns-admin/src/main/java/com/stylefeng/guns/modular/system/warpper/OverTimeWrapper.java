package com.stylefeng.guns.modular.system.warpper;

import java.util.List;
import java.util.Map;

import com.stylefeng.guns.core.base.warpper.BaseControllerWarpper;
import com.stylefeng.guns.core.common.constant.factory.ConstantFactory;

public class OverTimeWrapper extends BaseControllerWarpper {

    public OverTimeWrapper(List<Map<String, Object>> list) {
        super(list);
    }

    @Override
    public void warpTheMap(Map<String, Object> map) {
    	map.put("submitStatusName", ConstantFactory.me().getSubmitStatusName((Integer) map.get("submitStatus")));
    	//map.put("userName", map.get("userId"));
    	map.put("projectName", ConstantFactory.me().getProjectNameByUserId(map.get("userId").toString()));
    	map.put("vendorName", ConstantFactory.me().getVendorNameByUserId(map.get("userId").toString()));
    	map.put("vendorUserChName", ConstantFactory.me().getVendorUserByAccount(map.get("userId").toString()).getUserNameCh());
    	map.put("vendorUserEnName", ConstantFactory.me().getVendorUserByAccount(map.get("userId").toString()).getUserNameEn());
    	map.put("postionName", ConstantFactory.me().getVendorUserPositionName(ConstantFactory.me().getVendorUserByAccount(map.get("userId").toString()).getPositionId()));
    	map.put("overDateStr", map.get("overDate").toString());
    }
}